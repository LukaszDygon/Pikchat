module.exports = {
	user: require('./user.js'),
	picture: require('./picture.js')

}